<?php

declare(strict_types=1);

namespace WpPager\Exceptions;

use Exception;

class MissingRequestParameter extends Exception
{
}
